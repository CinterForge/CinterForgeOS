#!/bin/bash
# Shared, per-launch diagnostics on the host-visible /run/steamapps/common/CinterForge/Applications VirtioFS mount.
# Source this file from Bash launchers; does not modify application installations.
# Logs can contain usernames, process arguments and application diagnostics. Keep local.
cfdiag_init() {
    local app="$1" stamp
    stamp="$(date +%Y-%m-%d_%H-%M-%S)-$$"
    CF_DIAG_START="$(date --iso-8601=seconds)"
    CF_DIAG_ROOT="/run/steamapps/common/CinterForge/Applications/Logs/$app/$stamp"
    # Never silently write to a guest-only directory if the requested host mount is missing.
    if ! mountpoint -q /run/steamapps/common/CinterForge/Applications || ! mkdir -p "$CF_DIAG_ROOT" 2>/dev/null || ! test -w "$CF_DIAG_ROOT"; then
        CF_DIAG_ROOT="$HOME/.local/state/cinterforge/diagnostics-fallback/$app/$stamp"
        mkdir -p "$CF_DIAG_ROOT"
        printf '[diagnostics] WARNING: /run/steamapps/common/CinterForge/Applications/Logs is unavailable or read-only; using guest fallback %s\n' "$CF_DIAG_ROOT" >&2
    fi
    export CF_DIAG_ROOT
    printf '%s\n' "$CF_DIAG_START" >"$CF_DIAG_ROOT/started.txt"
    {
      printf 'app=%s\nstart=%s\npid=%s\nuid=%s\n' "$app" "$CF_DIAG_START" "$$" "$(id -u)"
      printf 'guest_arch=%s\nkernel=%s\n' "$(uname -m)" "$(uname -r)"
      printf 'session=%s\nxdg_type=%s\ndisplay=%s\nwayland=%s\n' \
        "${XDG_CURRENT_DESKTOP:-}" "${XDG_SESSION_TYPE:-}" "${DISPLAY:-}" "${WAYLAND_DISPLAY:-}"
      printf 'path=%s\n' "$PATH"
      printf 'Applications_mount='; findmnt -rn --mountpoint /run/steamapps/common/CinterForge/Applications -o SOURCE,FSTYPE,OPTIONS || true
      printf 'layer_release='; cat /etc/os-release 2>/dev/null | head -6 || true
    } >"$CF_DIAG_ROOT/context.txt" 2>&1
    # Journals stream throughout the launch rather than relying on a crash surviving to finalization.
    if command -v journalctl >/dev/null 2>&1; then
        (exec journalctl --user -n 0 --follow --no-pager -o short-iso >"$CF_DIAG_ROOT/journal-user-live.log" 2>&1) &
        CF_DIAG_USER_PID=$!
        (exec journalctl -k -n 0 --follow --no-pager -o short-iso >"$CF_DIAG_ROOT/journal-kernel-live.log" 2>&1) &
        CF_DIAG_KERNEL_PID=$!
        (exec journalctl -b -n 0 --follow --no-pager -o short-iso >"$CF_DIAG_ROOT/journal-system-live.log" 2>&1) &
        CF_DIAG_SYSTEM_PID=$!
    fi
    (while :; do
        printf '\n--- %s ---\n' "$(date --iso-8601=seconds)"
        ps -eo pid,ppid,stat,comm,args --width 220 2>&1 | grep -Ei '(^ *PID|steam|cfaudio|wine|wineserver|fex|gamescope|kwin|pressure-vessel|steamwebhelper|proton)' || true
        sleep 3
    done) >"$CF_DIAG_ROOT/process-timeline.log" 2>&1 &
    CF_DIAG_PS_PID=$!
    printf '[diagnostics] Mac-hosted launch directory: %s\n' "$CF_DIAG_ROOT" >&2
    # Capture stdout/stderr without losing them from the window/session journal.
    exec > >(tee -a "$CF_DIAG_ROOT/launch.log") 2>&1
}
cfdiag_finish() {
    local code="$1" child
    # Disable error traps in the collection path; diagnostics must not mask app exit status.
    trap - EXIT ERR
    printf '[diagnostics] exit=%s at=%s folder=%s\n' "$code" "$(date --iso-8601=seconds)" "$CF_DIAG_ROOT"
    printf '%s\n' "$code" >"$CF_DIAG_ROOT/exit-code.txt"
    date --iso-8601=seconds >"$CF_DIAG_ROOT/ended.txt"
    for child in "${CF_DIAG_USER_PID:-}" "${CF_DIAG_KERNEL_PID:-}" "${CF_DIAG_SYSTEM_PID:-}" "${CF_DIAG_PS_PID:-}"; do
        [[ -n $child ]] && kill "$child" 2>/dev/null || true
    done
    (
        printf '==== Installed runtime commands ====\n'
        for cmd in FEX FEXBash wine wine64 proton steam coredumpctl file readelf ldconfig; do
            command -v "$cmd" 2>/dev/null || true
        done
        printf '\n==== GPU / memory / mounts ====\n'
        free -h 2>&1 || true
        df -h /run/steamapps/common/CinterForge/Applications "$HOME" 2>&1 || true
        findmnt -rn -t virtiofs 2>&1 || true
        printf '\n==== Last relevant processes ====\n'
        ps -eo pid,ppid,stat,comm,args --width 220 2>&1 | grep -Ei 'steam|cfaudio|wine|fex|gamescope|kwin' || true
    ) >"$CF_DIAG_ROOT/runtime-state.txt" 2>&1
    if command -v journalctl >/dev/null 2>&1; then
        journalctl --user --since "$CF_DIAG_START" --no-pager -o short-iso >"$CF_DIAG_ROOT/journal-user.log" 2>&1 || true
        journalctl -b --since "$CF_DIAG_START" --no-pager -o short-iso >"$CF_DIAG_ROOT/journal-system.log" 2>&1 || true
        journalctl -k --since "$CF_DIAG_START" --no-pager -o short-iso >"$CF_DIAG_ROOT/journal-kernel.log" 2>&1 || true
    fi
    if command -v coredumpctl >/dev/null 2>&1; then
        coredumpctl --no-pager --since "$CF_DIAG_START" list >"$CF_DIAG_ROOT/coredumps.txt" 2>&1 || true
    fi
    if [[ $CF_DIAG_ROOT == */Steam/* ]]; then
        # Steam writes its own renderer/bootstrap diagnostics outside stdout.
        local client_logdir="$HOME/.local/share/Steam/logs" filename
        if [[ -d $client_logdir ]]; then
            mkdir -p "$CF_DIAG_ROOT/steam-client-logs"
            while IFS= read -r -d '' filename; do
                cp -p -- "$filename" "$CF_DIAG_ROOT/steam-client-logs/" 2>/dev/null || true
            done < <(find "$client_logdir" -maxdepth 1 -type f -newer "$CF_DIAG_ROOT/started.txt" -print0 2>/dev/null)
        fi
    fi
    # Do not copy full core dumps (can be massive and contain private data).
    # Store metadata and diagnostic process output instead.
    return 0
}
