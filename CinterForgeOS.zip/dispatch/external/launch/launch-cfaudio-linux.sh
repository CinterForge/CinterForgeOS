#!/bin/sh
# Launch the installed Linux x86-64 Ardour engine, not the build-tree wrapper.
# Upstream's bin/ardour9 launcher may embed /work/Install from its build host.
set -eu
base='/run/steamapps/common/CinterForge/Applications/Linux/CinterForge Audio'
if [ "$#" -gt 0 ] && [ -d "$1" ]; then root=$1; shift
else
    [ -d "$base" ] || { echo "Linux CinterForge Audio installation missing: $base" >&2; exit 1; }
    root=$(find "$base" -mindepth 1 -maxdepth 1 -type d -print | LC_ALL=C sort -V | tail -n 1)
fi
[ -n "${root:-}" ] && [ -d "$root" ] || { echo "No installed Linux version under $base" >&2; exit 1; }

# The actual binary normally lives in lib/ardour9. Select only ELF files:
# bin/ardour9 is commonly a shell script with stale build-machine paths.
engine=
for candidate in "$root"/lib/ardour9/ardour-[0-9]* "$root"/lib/ardour9/cfaudio-[0-9]* "$root"/bin/ardour-[0-9]* "$root"/bin/cfaudio-[0-9]* "$root"/bin/ardour9; do
    [ -f "$candidate" ] && [ -x "$candidate" ] || continue
    case "$candidate" in *.exe|*.dll|*.so|*.debug) continue ;; esac
    magic=$(LC_ALL=C od -An -tx1 -N4 "$candidate" 2>/dev/null | tr -d ' \n')
    [ "$magic" = 7f454c46 ] || continue
    engine=$candidate
    break
done
if [ -z "$engine" ]; then
    echo "Linux Ardour ELF engine is missing from $root/lib/ardour9 and $root/bin." >&2
    echo 'The bin/ardour9 shell wrapper is not usable: it refers to the build-time /work/Install directory.' >&2
    echo 'The installed application must contain the real engine binary and libraries; repair Ardour staging, not SteamOS paths.' >&2
    ls -la "$root/bin" "$root/lib/ardour9" >&2 2>/dev/null || true
    exit 1
fi
command -v Cinter >/dev/null 2>&1 || { echo 'Shared Linux x86-64 runner missing' >&2; exit 1; }
# Bundled Ubuntu AMD64 application dependencies must be visible to the FEX
# loader. Keep the application's own libraries ahead of the packaged closure.
export LD_LIBRARY_PATH="$root/lib:$root/lib/ardour9:$root/lib/runtime${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ARDOUR_DATA_PATH="$root/share/ardour9"
export ARDOUR_CONFIG_PATH="$root/etc/ardour9"
export ARDOUR_DLL_PATH="$root/lib/ardour9"
export VAMP_PATH="$root/lib/ardour9/vamp${VAMP_PATH:+:$VAMP_PATH}"
export UBUNTU_MENUPROXY=''
export ARDOUR_SELF=ardour9
printf '[CinterForgeOS] Linux Ardour ELF: %s\n' "$engine" >&2
exec Cinter run-linux-amd64 "$engine" "$@"
