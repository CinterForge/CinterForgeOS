#!/bin/sh
# CinterForgeOS standalone FEX / Wine smoke test. No reference apps required.
# Run inside the native SteamOS KDE guest. Never changes the installed applications.
set -u
root=/usr/share/cinterforge/fex/RootFS
test_scripts_directory=${CINTERFORGE_TEST_SCRIPTS_DIRECTORY:-/run/steamapps/common/CinterForge/Applications/Test/Scripts}
wine="$test_scripts_directory/wine/cinterforge-wine.sh"
runner="$test_scripts_directory/run/run-linux-amd64.sh"
results=/run/steamapps/common/CinterForge/Applications/Logs/Runtime
mkdir -p "$results" || { echo "[FAIL] Host runtime logs not writable: $results" >&2; exit 1; }
report="$results/FEX-Wine-SmokeTest.log"
# Replace the previous report rather than appending timestamped diagnostics.
: > "$report" || exit 1
(
  printf '[CinterForgeOS] FEX/Wine smoke test, architecture=%s\n' "$(uname -m)"
  failed=0
  if [ ! -x /usr/bin/FEX ]; then echo '[FAIL] /usr/bin/FEX missing'; failed=1; fi
  if [ ! -x "$root/usr/bin/bash" ]; then echo "[FAIL] x86-64 RootFS shell missing: $root"; failed=1; fi
  for soname in libglib-2.0.so.0 libpangomm-1.4.so.1; do
    if [ -e "$root/usr/lib/x86_64-linux-gnu/$soname" ]; then
      echo "[PASS] RootFS library $soname"
    else
      echo "[FAIL] RootFS library $soname"; failed=1
    fi
  done
  if [ "$failed" -eq 0 ]; then
    echo '[CHECK] FEX executes Debian x86-64 /usr/bin/uname'
    if architecture=$("$runner" "$root/usr/bin/uname" -m 2>&1); then
      printf '[INFO] FEX reported architecture: %s\n' "$architecture"
      if [ "$architecture" = x86_64 ]; then echo '[PASS] FEX process'; else echo '[FAIL] FEX did not report x86_64'; failed=1; fi
    else echo "[FAIL] FEX process: $architecture"; failed=1; fi
  fi
  if [ ! -x "$wine" ]; then echo "[FAIL] Wine launcher missing: $wine"; failed=1
  else
    echo '[CHECK] Wine initializes with built-in cmd.exe'
    # Separate, explicit test prefix; do not touch a user's Wine profile.
    export WINEPREFIX="${TMPDIR:-/tmp}/cinterforge-fex-wine-smoke-$(id -u)"
    export WINEDEBUG=-all
    if "$wine" cmd.exe /c ver; then echo '[PASS] Wine cmd.exe'; else echo '[FAIL] Wine cmd.exe (check kernel32 and DLL layout)'; failed=1; fi
    if [ "${1:-}" = '--gui' ] && [ "$failed" -eq 0 ]; then
      echo '[CHECK] Starting built-in Windows Notepad; close window to finish test'
      if "$wine" notepad.exe; then echo '[PASS] Wine Notepad GUI'; else echo '[FAIL] Wine Notepad GUI'; failed=1; fi
    fi
  fi
  if [ -n "${WINEPREFIX:-}" ]; then
    case "$WINEPREFIX" in "${TMPDIR:-/tmp}"/cinterforge-fex-wine-smoke-*) rm -rf -- "$WINEPREFIX" ;; esac
  fi
  echo "[RESULT] $([ "$failed" -eq 0 ] && echo PASS || echo FAIL)"
  exit "$failed"
) > "$report" 2>&1
status=$?
cat "$report"
exit "$status"
